class NFT:
    def __init__(self, name, artist, price):
        self.name = name
        self.artist = artist
        self.price = price