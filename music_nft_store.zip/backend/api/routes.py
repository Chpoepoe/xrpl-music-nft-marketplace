from fastapi import APIRouter

router = APIRouter()

@router.get('/nfts')
def get_nfts():
    return [{'name': 'NFT Song', 'artist': 'DJ Future', 'price': 100}]